﻿using System.Globalization;

namespace PrimeiroProjetoCSharp
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //URI 1001
                int A, B, X;
                A = int.Parse(Console.ReadLine());
                B = int.Parse(Console.ReadLine());
        
                X = A + B;
        
                Console.WriteLine("X = " + X);
          
            //URI 1002
                area = n.raio² (n=3.14159)
                double raio, n, area;
                n = 3.14159;

                raio = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);

                area = n * Math.Pow(raio, 2);

                Console.WriteLine("A=" + area.ToString("F4", CultureInfo.InvariantCulture));

            //URI 1003
                int A, B, Soma;
                A = int.Parse(Console.ReadLine());
                B = int.Parse(Console.ReadLine());

                Soma = A + B;

                Console.WriteLine("SOMA = " + Soma);

            //URI 1004
                int A, B, PROD;
                A = int.Parse(Console.ReadLine());
                B = int.Parse(Console.ReadLine());

                PROD = A * B;
                Console.WriteLine("PROD = " + PROD);

            //URI 1007
                int A, B, C, D, diferenca;
                A = int.Parse(Console.ReadLine());
                B = int.Parse(Console.ReadLine());
                C = int.Parse(Console.ReadLine());
                D = int.Parse(Console.ReadLine());

                diferenca = A * B - C * D;
                Console.WriteLine("DIFERENCA = " + diferenca);

            //URI 1008
                int Number, Hour;
                double salary, pay;

                Number = int.Parse(Console.ReadLine());
                Hour = int.Parse(Console.ReadLine());
                salary = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);
                
                pay = salary * Hour;
                
                Console.WriteLine("NUMBER = " + Number);
                Console.WriteLine("SALARY = U$ " + pay.ToString("F2", CultureInfo.InvariantCulture);
            
            //URI 1010
                int Number1, Number2, Qtd1, Qtd2;
                double Price1, Price2, Total;

                string[] vet1 = Console.ReadLine().Split(' ');
                Number1 = int.Parse(vet1[0]);
                Qtd1 = int.Parse(vet1[1]);
                Price1 = double.Parse(vet1[2]);

                string[] vet2 = Console.ReadLine().Split(' ');
                Number2 = int.Parse(vet2[0]);
                Qtd2 = int.Parse(vet2[1]);
                Price2 = double.Parse(vet2[2]);

                Total = (Price1 * Qtd1) + (Price2 * Qtd2);

                Console.WriteLine("VALOR A PAGAR: R$ " + Total.ToString("F2"));

            //URI 1014
                int X;
                double Y, Avg;
                
                X = int.Parse(Console.ReadLine());
                Y = double.Parse(Console.ReadLine());
                
                Avg = X / Y;
                
                Console.WriteLine(Avg.ToString("F3") + " km/l");

            //URI 1016
                int X, Y;
                
                X = int.Parse(Console.ReadLine());

                Y = X * 2;
                
                Console.WriteLine(Y + " minutos");

            //URI 1017
                int Time, Velocity;
                double Consumer;

                Time = int.Parse(Console.ReadLine());
                Velocity = int.Parse(Console.ReadLine());

                Consumer = ((double) Time * (double) Velocity) / 12.0;

                Console.WriteLine(Consumer.ToString("F3"));

            //URI 1005
                double N1, N2, Note;

                N1 = double.Parse(Console.ReadLine());
                N2 = double.Parse(Console.ReadLine());

                N1 = (N1 / 11.0) * 3.5;
                N2 = (N2 / 11.0) * 7.5;

                Note = (N1 + N2); 
                Console.WriteLine("MEDIA = " + Note.ToString("F5"));
            
            //URI 1006
                double A, B, C, Note;
                
                A = double.Parse(Console.ReadLine());
                B = double.Parse(Console.ReadLine());
                C = double.Parse(Console.ReadLine());

                A = (A / 10) * 2.0;
                B = (B / 10) * 3.0;
                C = (C / 10) * 5.0;
                
                Note = (A + B + C);

                Console.WriteLine("MEDIA = " + Note.ToString("F1"));

            //URI 1019
                int N, horas, minutos, segundos, resto;

                N = int.Parse(Console.ReadLine());

                horas = N / 3600;
                resto = N % 3600;

                minutos = resto / 60;
                segundos = resto % 60;

                Console.WriteLine(horas + ":" + minutos + ":" + segundos);    
            
            //URI 1009
                string Name;
                double Salary, Sales, Payment;

                Name = Console.ReadLine();
                Salary = double.Parse(Console.ReadLine());
                Sales = double.Parse(Console.ReadLine());
                
                Payment = (Sales * 0.15) + Salary;
                
                Console.WriteLine("TOTAL = R$ " + Payment.ToString("F2"));

            //URI 1011
                int R;
                double Vol, PI = 3.14159;

                R = int.Parse(Console.ReadLine());

                Vol = (4/3.0) * PI * Math.Pow(R,3);

                Console.WriteLine("VOLUME = " + Vol.ToString("F3"));
            
            //URI 1012            
                double A, B, C, Triangulo, Circulo, Trapezio, Quadrado, Retangulo, PI = 3.14159;

                string[] vet = Console.ReadLine().Split(' ');
                A = double.Parse(vet[0]);
                B = double.Parse(vet[1]);
                C = double.Parse(vet[2]);

                Triangulo = A * C / 2.0;
                Circulo = PI * C * C;
                Trapezio = (A + B) / 2.0 * C;
                Quadrado = B * B;
                Retangulo = A * B;

                Console.WriteLine("TRIANGULO: " + Triangulo.ToString("F3"));
                Console.WriteLine("CIRCULO: " + Circulo.ToString("F3"));
                Console.WriteLine("TRAPEZIO: " + Trapezio.ToString("F3"));
                Console.WriteLine("QUADRADO: " + Quadrado.ToString("F3"));
                Console.WriteLine("RETANGULO: " + Retangulo.ToString("F3"));
            
            //URI 1013
                int A, B, C, MaiorAB, Maior;

                string[] vet = Console.ReadLine().Split(' ');

                A = int.Parse(vet[0]);
                B = int.Parse(vet[1]);
                C = int.Parse(vet[2]);

                MaiorAB = (A + B + Math.Abs(A - B)) / 2;

                Maior = (C + MaiorAB + Math.Abs(C - MaiorAB)) / 2;

                Console.WriteLine(Maior + " eh o maior");

            //URI 1015
                double X1, X2, Y1, Y2, Dif;

                string[] vet1 = Console.ReadLine().Split(' ');
                string[] vet2 = Console.ReadLine().Split(' ');

                X1 = double.Parse(vet1[0]);
                Y1 = double.Parse(vet1[1]);
                X2 = double.Parse(vet2[0]);
                Y2 = double.Parse(vet2[1]);

                Dif = Math.Sqrt(Math.Pow((X2 - X1), 2) + Math.Pow((Y2 - Y1), 2));

                Console.WriteLine(Dif.ToString("F4"));

            //URI 1018
                int Notas, N100, N50, N20, N10, N5, N2, N1;

                Notas = int.Parse(Console.ReadLine());

                int Nota100 = 100;
                N100 = Notas / 100;

                int Nota50 = 50;
                N50 = (Notas % 100) / 50;

                int Nota20 = 20;
                N20 = ((Notas % 100) % 50) / 20;

                int Nota10 = 10;
                N10 = (((Notas % 100) % 50) % 20) / 10;

                int Nota5 = 5;
                N5 = ((((Notas % 100) % 50) % 20) % 10) / 5;

                int Nota2 = 2;
                N2 = (((((Notas % 100) % 50) % 20) % 10) % 5) / 2;

                int Nota1 = 1;
                N1 = ((((((Notas % 100) % 50) % 20) % 10) % 5) % 2) / 1;

                Console.WriteLine(Notas);
                Console.WriteLine(N100 + " nota(s) de R$ " + Nota100 +",00");
                Console.WriteLine(N50 + " nota(s) de R$ " + Nota50 + ",00");
                Console.WriteLine(N20 + " nota(s) de R$ " + Nota20 + ",00");
                Console.WriteLine(N10 + " nota(s) de R$ " + Nota10 + ",00");
                Console.WriteLine(N5 + " nota(s) de R$ " + Nota5 + ",00");
                Console.WriteLine(N2 + " nota(s) de R$ " + Nota2 + ",00");
                Console.WriteLine(N1 + " nota(s) de R$ " + Nota1 + ",00");
            
            //URI 1020
                int N, A, M, D;
            
                N = int.Parse(Console.ReadLine());

                A = N / 365;
                M = (N % 365) / 30;
                D = (N % 365) % 30;

                Console.WriteLine(A + " ano(s)");
                Console.WriteLine(M + " mes(es)");
                Console.WriteLine(D + " dia(s)");
            
            //URI 1021
                double N;
                int quociente, resto, nota, moeda;

                N = double.Parse(Console.ReadLine());

                resto = (int)(N * 100.0 + 0.5);

                Console.WriteLine("NOTAS:");
                nota = 100;
                quociente = resto / (nota * 100);
                Console.WriteLine(quociente + " nota(s) de R$ " + nota + ".00");
                resto = resto % (nota * 100);

                nota = 50;
                quociente = resto / (nota * 100);
                Console.WriteLine(quociente + " nota(s) de R$ " + nota + ".00");
                resto = resto % (nota * 100);

                nota = 20;
                quociente = resto / (nota * 100);
                Console.WriteLine(quociente + " nota(s) de R$ " + nota + ".00");
                resto = resto % (nota * 100);

                nota = 10;
                quociente = resto / (nota * 100);
                Console.WriteLine(quociente + " nota(s) de R$ " + nota + ".00");
                resto = resto % (nota * 100);

                nota = 5;
                quociente = resto / (nota * 100);
                Console.WriteLine(quociente + " nota(s) de R$ " + nota + ".00");
                resto = resto % (nota * 100);

                nota = 2;
                quociente = resto / (nota * 100);
                Console.WriteLine(quociente + " nota(s) de R$ " + nota + ".00");
                resto = resto % (nota * 100);

                Console.WriteLine("MOEDAS:");

                moeda = 100;
                quociente = resto / moeda;
                Console.WriteLine(quociente + " moeda(s) de R$ 1.00");
                resto = resto % moeda;

                moeda = 50;
                quociente = resto / moeda;
                Console.WriteLine(quociente + " moeda(s) de R$ 0.50");
                resto = resto % moeda;

                moeda = 25;
                quociente = resto / moeda;
                Console.WriteLine(quociente + " moeda(s) de R$ 0.25");
                resto = resto % moeda;

                moeda = 10;
                quociente = resto / moeda;
                Console.WriteLine(quociente + " moeda(s) de R$ 0.10");
                resto = resto % moeda;

                moeda = 5;
                quociente = resto / moeda;
                Console.WriteLine(quociente + " moeda(s) de R$ 0.05");
                resto = resto % moeda;

                Console.WriteLine(resto + " moeda(s) de R$ 0.01");

            //URI 1061
                int W1, X1, Y1, Z1, W2, X2, Y2, Z2, W, X, Y, Z, inicio, fim, duracao, resto;

                // Ler a primeira linha, armazenando o valor de W (dia)
                string[] valores = Console.ReadLine().Split(' ');
                W1 = int.Parse(valores[1]);

                // Ler a segunda linha, armazenando o valor de X (hora), Y (minuto), Z (segundo)
                valores = Console.ReadLine().Split(' ');
                X1 = int.Parse(valores[0]);
                Y1 = int.Parse(valores[2]);
                Z1 = int.Parse(valores[4]);

                // Ler a terceira linha, armazenando o valor de W (dia)
                valores = Console.ReadLine().Split(' ');
                W2 = int.Parse(valores[1]);

                // Ler a segunda linha, armazenando o valor de X (hora), Y (minuto), Z (segundo)
                valores = Console.ReadLine().Split(' ');
                X2 = int.Parse(valores[0]);
                Y2 = int.Parse(valores[2]);
                Z2 = int.Parse(valores[4]);

                // Calculando o valor do inicio e fim, convertendo tudo para segundos
                inicio = (W1 - 1) * 24 * 60 * 60 + X1 * 60 * 60 + Y1 * 60 + Z1;
                fim = (W2 - 1) * 24 * 60 * 60 + X2 * 60 * 60 + Y2 * 60 + Z2;
            
                // Calculando a duracao em segundos
                duracao = fim - inicio;

                // Agora vamos desmembrar a duracao em segundos para dia (W), hora (X), minutos (Y) e segundos (Z) restantes
                W = duracao / (24 * 60 * 60);
                resto = duracao % (24 * 60 * 60);
                X = resto / (60 * 60);
                resto = resto % (60 * 60);
                Y = resto / 60;
                Z = resto % 60;

                Console.WriteLine(W + " dia(s)");
                Console.WriteLine(X + " hora(s)");
                Console.WriteLine(Y + " minuto(s)");
                Console.WriteLine(Z + " segundo(s)");

            //URI 1036
                double A, B, C, Delta, R1, R2;

                string[] vet = Console.ReadLine().Split(' ');
                A = double.Parse(vet[0]);
                B = double.Parse(vet[1]);
                C = double.Parse(vet[2]);

                Delta = Math.Pow(B, 2.0) - 4.0 * A * C;

                if (A == 0 || Delta < 0.0)
                {
                    Console.WriteLine("Impossivel calcular");
                } else
                {
                    R1 = (-B + Math.Sqrt(Delta)) / (2.0 * A);
                    R2 = (-B - Math.Sqrt(Delta)) / (2.0 * A);

                    Console.WriteLine("R1 = " + R1.ToString("F5"));
                    Console.WriteLine("R2 = " + R2.ToString("F5"));
                }

            //URI 1035
                int A, B, C, D;

                string[] vet = Console.ReadLine().Split(' ');
                A = int.Parse(vet[0]);
                B = int.Parse(vet[1]);
                C = int.Parse(vet[2]);
                D = int.Parse(vet[3]);

                if (B > C && D > A && C + D > A + B && C > 0 && D > 0 && A % 2 == 0)
                {
                    Console.WriteLine("Valores aceitos");
                }
                else
                {
                    Console.WriteLine("Valores nao aceitos");
                }
            /*
            URI 1038
            URI 1044
            URI 1046
            URI 1048
            URI 1037
            URI 1040
            URI 1041
            URI 1045
            URI 1047
            URI 1049
            URI 1051
            URI 1042
            URI 1043
            URI 1050
            URI 1052
            URI 1060
            URI 1064
            URI 1065
            URI 1066
            URI 1070
            */
        }
    }
}